<?php
include('../config.php');
session_start();

$query = mysql_query("SELECT token FROM `users` WHERE `email` = '".$_SESSION['uid']."'"); 
  while($info=mysql_fetch_array($query)) {
	$user_key=$info['token'];  
  }
  
$query = mysql_query("SELECT token FROM `listing` WHERE `id` = '".$_GET['id']."'"); 
  while($info=mysql_fetch_array($query)) {
	$listing_key=$info['token'];  
  }
  
  if($user_key!=$listing_key){
	  echo 'auth fail';
	  exit;
  }
  
?>
<html>
<head>
<title>findmyboat</title>
</head>
<!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../dist/css/bootstrapValidator.css"/>
     <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript" src="scripts/jquery.min.js"></script>
<script type="text/javascript" src="scripts/jquery.wallform.js"></script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').die('click').live('change', function()			{ 
			           //$("#preview").html('');
			    
				$("#imageform").ajaxForm({target: '#preview', 
				     beforeSubmit:function(){ 
					
					console.log('v');
					$("#imageloadstatus").show();
					 $("#imageloadbutton").hide();
					 }, 
					success:function(){ 
					console.log('z');
					 $("#imageloadstatus").hide();
					 $("#imageloadbutton").show();
					}, 
					error:function(){ 
							console.log('d');
					 $("#imageloadstatus").hide();
					$("#imageloadbutton").show();
					} }).submit();
					
		
			});
        }); 
</script>

<style>

body
{
font-family:arial;
}
.preview
{
width:200px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}

</style>
<body>
<div class="container">
<div class="well">
<a href="../viewListings.php?display=edit" class="btn btn-lg btn-success pull-right">Submit for Approval</a><h1>Upload Pictures for your listing!</h1>
<hr>

<div class="row">
<div class="col-md-8">
<h4>Current Main Picture :</h4>
<?php
$query = mysql_query("SELECT photo1 FROM `listing` WHERE `id` = '".$_GET['id']."'"); 
  while($info=mysql_fetch_array($query)) {
	if($info['photo1']){
	echo '<img href class="media-object" width="150px" src="uploads/'.$info['photo1'].'">';  
  } else echo 'Nil';  
  }
?>
</div>
<div class="col-md-4">

<h4>Update Main Picture :</h4>
	<div id='preview'>
	</div>

<form id="imageform" method="post" enctype="multipart/form-data" action='ajaximage.php'>
<br/>
<div id='imageloadstatus' style='display:none'><img src="loader.gif" alt="Uploading...."/></div>
<div id='imageloadbutton'>
<input type="file" name="photoimg" id="photoimg" />
<input type="text" name="id" hidden value="<?php echo $_GET['id']; ?>">
</div>
</form>
</div>
</div>

</div>

<hr>

<div class="well">
<h2 align="center">Ads with Photos sell 5X More!</h2>

<div class="row">
<div class="col-md-6">
<h2>Guidelines</h2>
<p>The picture should be less than 1 MB in size.</p>
<p>Use original photos in .jpg, .gif or .png</p>
<p>Avoid using low-light photos.</p>
</div>
<div class="col-md-6">
<h2>Moderation</h2>
<p>Your listing will only be completed after moderation.</p>
<p>Provide Valid Information.</p>
<p>Avoid using illegal stuffs.</p>
</div>
</div>
<a href="../viewListings.php?display=edit" class="btn btn-lg btn-success pull-right">Submit for Approval</a>
</div>

</div>

<div class="footer">
      <hr>
      <div align="center" class="container">
              <p><a href="list.php">List your Boat</a> | About | Powered by <a href="http://techulus.com">Techulus</a></p>
            </div>
          </div>
</body>
</html>